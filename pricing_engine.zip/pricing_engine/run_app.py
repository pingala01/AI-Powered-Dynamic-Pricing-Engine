"""One-click launcher. Works in IDLE (open this file, press F5) and in CMD (python run_app.py).
It installs missing packages, starts the Streamlit dashboard and opens your browser.
"""
import importlib.util
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PORT = "8501"
MODULES = ["numpy", "pandas", "sklearn", "plotly", "streamlit"]


def main():
    print("Python:", sys.version.split()[0])
    missing = [m for m in MODULES if importlib.util.find_spec(m) is None]
    if missing:
        print("Installing required packages (first run only, may take a few minutes)...")
        code = subprocess.call([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")])
        if code != 0:
            print("\nInstallation failed. Check your internet connection and the messages above.")
            return
    print("Starting dashboard... press Ctrl+C here (or close this window) to stop it.")
    proc = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", str(ROOT / "app.py"),
         "--server.headless", "true", "--server.port", PORT,
         "--browser.gatherUsageStats", "false"],
        cwd=str(ROOT))
    try:
        time.sleep(5)
        webbrowser.open("http://localhost:" + PORT)
        proc.wait()
    except KeyboardInterrupt:
        pass
    finally:
        if proc.poll() is None:
            proc.terminate()
        print("Dashboard stopped.")


if __name__ == "__main__":
    main()
