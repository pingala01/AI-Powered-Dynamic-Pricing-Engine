"""Tests for the four core features. Run from the project folder:
    python -m unittest discover -s tests -v
"""
import sys
import unittest
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.data_utils import DataValidationError, validate_and_clean  # noqa: E402
from src.flash_sale import detect_flash_sales  # noqa: E402
from src.forecasting import forecast_all  # noqa: E402
from src.generate_sample_data import make_sample_data  # noqa: E402
from src.optimization import analyze_inventory_revenue  # noqa: E402
from src.pricing import recommend_prices  # noqa: E402


class PipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df, _ = validate_and_clean(make_sample_data())
        cls.forecasts = forecast_all(cls.df, 14)
        cls.flash = detect_flash_sales(cls.df)
        cls.recs = recommend_prices(cls.df, cls.forecasts, cls.flash)
        cls.inv = analyze_inventory_revenue(cls.df, cls.recs)

    def row(self, table, pid):
        return table[table["product_id"] == pid].iloc[0]

    # ---- data validation
    def test_missing_column_gives_clear_error(self):
        with self.assertRaises(DataValidationError) as ctx:
            validate_and_clean(make_sample_data().drop(columns=["competitor_price"]))
        self.assertIn("competitor_price", str(ctx.exception))

    def test_negative_price_rejected(self):
        bad = make_sample_data()
        bad.loc[0, "current_price"] = -5
        with self.assertRaises(DataValidationError):
            validate_and_clean(bad)

    def test_empty_file_rejected(self):
        with self.assertRaises(DataValidationError):
            validate_and_clean(pd.DataFrame())

    # ---- feature 2: demand forecasting
    def test_forecast_shape_and_values(self):
        for pid, fr in self.forecasts.items():
            self.assertEqual(len(fr.future), 14)
            self.assertTrue((fr.future["predicted"] >= 0).all())
            self.assertEqual(int(fr.history["predicted"].notna().sum()), 14)  # hold-out predictions
            self.assertLess(fr.wape, 1.0)

    # ---- feature 4: flash sale detection
    def test_flash_sale_detected_only_for_surge_product(self):
        flagged = set(self.flash[self.flash["status"] == "Flash Sale"]["product_id"])
        self.assertEqual(flagged, {"P1004"})
        self.assertGreater(self.row(self.flash, "P1004")["emergency_adjust_pct"], 0)

    def test_no_flash_sale_without_surge(self):
        last = self.df["date"].max()
        calm = self.df[~((self.df["product_id"] == "P1004") & (self.df["date"] > last - pd.Timedelta(days=3)))]
        self.assertNotIn("Flash Sale", set(detect_flash_sales(calm)["status"]))

    # ---- feature 1: dynamic pricing
    def test_every_recommendation_has_reasons_and_valid_price(self):
        for _, r in self.recs.iterrows():
            self.assertGreater(len(r["reasons"]), 0)
            self.assertGreater(r["recommended_price"], 0)
            self.assertLessEqual(abs(r["change_pct"]), 20.5)

    def test_pricing_responds_to_signals(self):
        self.assertEqual(self.row(self.recs, "P1001")["action"], "Increase")   # very low stock
        self.assertEqual(self.row(self.recs, "P1003")["action"], "Decrease")   # excess stock
        self.assertEqual(self.row(self.recs, "P1005")["action"], "Decrease")   # competitor cheaper
        self.assertEqual(self.row(self.recs, "P1004")["action"], "Increase")   # flash sale

    def test_features_work_together(self):
        reasons = " ".join(self.row(self.recs, "P1004")["reasons"])
        self.assertIn("Flash-sale pattern detected", reasons)

    # ---- feature 3: revenue and inventory optimization
    def test_inventory_classification(self):
        self.assertEqual(self.row(self.inv, "P1001")["status"], "Stockout Risk")
        self.assertEqual(self.row(self.inv, "P1003")["status"], "Excess Stock")
        self.assertEqual(self.row(self.inv, "P1002")["status"], "Healthy")


if __name__ == "__main__":
    unittest.main()
