"""Runs all tests. Works in IDLE (F5) and CMD (python run_tests.py)."""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
result = unittest.TextTestRunner(verbosity=2).run(suite)
print("\nALL TESTS PASSED" if result.wasSuccessful() else "\nSOME TESTS FAILED")
